from django.contrib import admin
from .models import Products
from .models import Order

admin.site.site_header="Admin Pannel Marks Music Store"
admin.site.site_title="Marks Music Store"
admin.site.index_title="Manage Marks Music Store"

class ProductAdmin(admin.ModelAdmin):

    def change_category_to_default(self,request,queryset):
        queryset.update(category="Music")

    change_category_to_default.short_description='Default Category'
    list_display = ('title','price','discount_price','category','description')
    search_fields = ('category',)
    actions = ('change_category_to_default',)
    #customise what fields are displayed in the Admin - Product - Dash Board
    fields = ('title','price','discount_price','category','description','image',)
    #edit the content fields that are displayed in the Admin - Product - Dash Board
    list_editable = ('price','category',)

admin.site.register(Products,ProductAdmin)
admin.site.register(Order)
